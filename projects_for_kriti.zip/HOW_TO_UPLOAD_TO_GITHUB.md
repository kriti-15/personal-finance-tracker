# 🚀 How to Upload These Projects to GitHub

Follow these steps for EACH project folder.

---

## Prerequisites (Do once)

1. Install Git: https://git-scm.com/downloads
2. Create a GitHub account: https://github.com
3. Configure Git with your name and email (run in terminal):
   ```bash
   git config --global user.name "Kriti"
   git config --global user.email "your-email@example.com"
   ```

---

## For Each Project (Repeat 3 times)

### Step 1 — Create a new repo on GitHub
1. Go to https://github.com/new
2. Repository name: e.g. `personal-finance-tracker`
3. Description: e.g. "A Python tool to track income and expenses using SQLite"
4. Set to **Public**
5. ✅ Check "Add a README file" — NO (we already have one)
6. Click **Create repository**

---

### Step 2 — Open Terminal / Command Prompt
Navigate into the project folder:
```bash
cd path/to/personal-finance-tracker
```

---

### Step 3 — Initialize Git and push
```bash
git init                          # Start tracking this folder with Git
git add .                         # Stage all files
git commit -m "Initial commit: Personal Finance Tracker"   # Save snapshot
git branch -M main                # Rename branch to 'main'
git remote add origin https://github.com/YOUR_USERNAME/personal-finance-tracker.git
git push -u origin main           # Upload to GitHub
```

Replace `YOUR_USERNAME` with your actual GitHub username.

---

### Step 4 — Repeat for the other two projects
- `stock-price-analyzer`
- `budget-automation`

---

## Tips for a Great GitHub Profile

- ✅ Always write a good `README.md` (already done!)
- 📌 Pin your best 6 repos on your profile page
- 💬 Write clear commit messages (e.g. "Add monthly summary feature")
- 🌱 Make small commits regularly — shows consistent activity
- 📖 Add topics/tags to each repo (e.g. `python`, `finance`, `beginner`)

---

## What to Learn Next

| Topic | Why |
|-------|-----|
| pandas | Core library for data analysis |
| matplotlib / seaborn | Data visualization |
| SQL (SQLite → PostgreSQL) | Database skills |
| Flask | Build web apps with Python |
| APIs (REST) | Connect to live financial data |
| R with ggplot2 | Advanced data visualization |

Good luck, Kriti! 🎉
