# 📈 Stock Price Analyzer

A beginner-friendly Python tool to download real stock market data, compute statistics, and generate visual charts — no paid API needed!

---

## 📌 Features

- 📡 Fetch real stock data (Indian NSE + US markets) via Yahoo Finance
- 📊 Compute high/low/average prices and % returns
- 📉 Plot closing price with 7-day & 30-day moving averages
- 📦 View trading volume as a bar chart
- 🆚 Compare performance of two stocks side by side

---

## 🛠️ Tech Stack

| Tool | Purpose |
|------|---------|
| Python 3 | Core language |
| yfinance | Free stock data from Yahoo Finance |
| pandas | Data manipulation and analysis |
| matplotlib | Chart plotting |

---

## 🚀 Getting Started

1. Clone the repo:
   ```bash
   git clone https://github.com/YOUR_USERNAME/stock-price-analyzer.git
   cd stock-price-analyzer
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Run the analyzer:
   ```bash
   python stock_analyzer.py
   ```

---

## 📦 Requirements

```
yfinance
pandas
matplotlib
```

Install all at once:
```bash
pip install yfinance pandas matplotlib
```

---

## 📸 Sample Output

```
📡 Fetching data for: RELIANCE.NS (last 90 days)...
✅ Downloaded 63 rows of data.

📊 Analysis for RELIANCE.NS
────────────────────────────────────────
  📈 Highest Close  : ₹ 2,987.45
  📉 Lowest  Close  : ₹ 2,601.30
  📐 Average Close  : ₹ 2,784.12
  🔄 Period Return  : +8.32%
  ✅ Stock is UP over this period.
✅ Chart saved as 'RELIANCE_NS_analysis.png'
```

---

## 🌱 Ideas to Extend

- Add RSI (Relative Strength Index) indicator
- Add email alerts when a stock crosses a threshold
- Build a simple stock screener
- Add support for mutual funds and ETFs

---

## 👩‍💻 Author

**Kriti** — Learning Python & FinTech | [GitHub](https://github.com/kriti-15)

---

## 📄 License

MIT License
