# 🤖 Monthly Budget Automation Tool

An automation script that reads your expense data from a CSV file, compares it against your monthly budget limits, generates visual reports, and alerts you when you've overspent.

---

## 📌 Features

- 📄 Reads expenses from a simple CSV file (editable in Excel)
- 📊 Compares spending vs budget per category
- 🔴 Highlights overspent categories with alerts
- 🥧 Generates a pie chart of spending breakdown
- 📝 Saves a text summary report automatically
- 🧪 Includes sample data to test immediately

---

## 🛠️ Tech Stack

| Tool | Purpose |
|------|---------|
| Python 3 | Core language |
| CSV module | Reading expense data |
| matplotlib | Pie chart generation |
| collections | Efficient data grouping |

---

## 🚀 Getting Started

1. Clone the repo:
   ```bash
   git clone https://github.com/YOUR_USERNAME/budget-automation.git
   cd budget-automation
   ```

2. Install dependencies:
   ```bash
   pip install matplotlib
   ```

3. Run the tool:
   ```bash
   python budget_automation.py
   ```

A sample `expenses.csv` will be auto-generated on first run. Edit it with your real data!

---

## 📁 CSV Format

Your `expenses.csv` should look like this:

```csv
date,category,amount,note
2025-07-01,rent,12000,Monthly rent
2025-07-02,food,450,Groceries
2025-07-03,transport,80,Metro card
```

---

## 📸 Sample Output

```
📊 Budget vs Actual Spending
─────────────────────────────────────────────────────────────────
  Category          Budget       Spent    Remaining  Status
─────────────────────────────────────────────────────────────────
  food            ₹  8,000   ₹ 4,860   ₹   3,140  🟢 OK
  transport       ₹  2,000   ₹   880   ₹   1,120  🟢 OK
  rent            ₹ 12,000  ₹ 12,000   ₹       0  🟢 OK
  entertainment   ₹  3,000   ₹ 2,699   ₹     301  🟡 WARN
  shopping        ₹  4,000   ₹ 4,300   ₹    -300  🔴 OVER

⚠️  OVERSPENDING ALERTS
────────────────────────────────────────
  🔴 SHOPPING: Overspent by ₹300.00
```

---

## 🌱 Ideas to Extend

- Add automatic email reports using `smtplib`
- Schedule it to run every month using `schedule` library
- Add category-wise bar chart comparison
- Integrate with Google Sheets for live tracking

---

## 👩‍💻 Author

**Kriti** — Learning Python & Automation | [GitHub](https://github.com/kriti-15)

---

## 📄 License

MIT License
