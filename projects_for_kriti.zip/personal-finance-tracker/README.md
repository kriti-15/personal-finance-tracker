# 💰 Personal Finance Tracker

A beginner-friendly command-line tool to track your daily income and expenses using **Python** and **SQLite**.

---

## 📌 Features

- ➕ Add income and expense transactions
- 📋 View all transactions in a clean table
- 📅 Get monthly summaries (income vs expenses vs savings)
- 📤 Export all data to CSV (open in Excel!)
- 🗃️ All data saved locally in a SQLite database

---

## 🛠️ Tech Stack

| Tool | Purpose |
|------|---------|
| Python 3 | Core language |
| SQLite3 | Local database (built into Python) |
| CSV module | Export data |

---

## 🚀 How to Run

1. Make sure Python 3 is installed:
   ```bash
   python --version
   ```

2. Clone this repo:
   ```bash
   git clone https://github.com/YOUR_USERNAME/personal-finance-tracker.git
   cd personal-finance-tracker
   ```

3. Run the app:
   ```bash
   python finance_tracker.py
   ```

No external libraries needed — runs on pure Python! ✅

---

## 📸 Sample Output

```
╔══════════════════════════════╗
║   💰 Personal Finance Tracker ║
╚══════════════════════════════╝
1. Add Income
2. Add Expense
3. View All Transactions
4. Monthly Summary
5. Export to CSV
6. Quit

📅 Summary for 2025-07
───────────────────────────────────
  💰 Total Income  : ₹45,000.00
  💸 Total Expenses: ₹28,500.00
  🏦 Net Savings   : ₹16,500.00
  ✅ Great job staying in the green!
```

---

## 🌱 Ideas to Extend This Project

- Add a chart using `matplotlib` to visualize spending by category
- Add a budget limit per category with alerts
- Build a web interface using Flask
- Sync data to Google Sheets using the Sheets API

---

## 👩‍💻 Author

**Kriti** — Learning Python & FinTech | [GitHub](https://github.com/kriti-15)

---

## 📄 License

MIT License — free to use and modify.
